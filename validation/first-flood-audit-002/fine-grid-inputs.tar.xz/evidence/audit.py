#!/usr/bin/env python3
"""Terminal-only fine125 first-flood audit. Read-only inputs; JSON goes to stdout.
Refuses to inspect terminal payloads while the original PID exists.
"""
import csv,hashlib,importlib.util,io,json,math,os,struct,sys,tarfile,time
from pathlib import Path
from datetime import datetime,timezone
sys.dont_write_bytecode=True
B=Path("/data/data0/brooke/alluvial-ridge")
W=B/"tmp/full-rebuild-002/workspace"
D=W/"validation/runs/fine125"
F=B/"validation/first-flood-audit-002"
BINARY="b3d984881a2f82757ff9bb6ca7c15f9e3c28e3d34106ae477fe7c06af6f8099c"
HELPER="7e304445cbc8fab0c6eb9068328d3707a9f47906ca21371c5f5b258fd0427073"
ARCHIVE="c604bd946596c7e25d0d4558ef955911d486099a605632fde2f7e65e35db30a6"
CAPTURE="b47e8c73d2ec99445678bb0d47614edbb021f73aba61d492581e6094135f6b5f"
SOURCES={"src/finite_volume.hpp":"57ac8606cd856046e13563fc0f07417943990fbc4f43340baf6f44aad427775d","src/main.cpp":"812058d4ff97b618da08830e44a8704e4dc3a1431e0245136a301a0cd4375c90","src/migration.hpp":"047475c7a53b933ccc83273e0576a820f681382fdf22b244a501006c68bf7196","src/model.hpp":"e12bb6c79a9e70ca53d555fc2d5cfcefed9b0cf2f8a3f7567defd650cc039a15","src/sediment.hpp":"3c698eaf05771c09a26a152697fdcdacacf59b08ad18345efcdcaf1e35ccd4d2"}

READINESS="f5846cdcdb466d51222d7f34c1de14368882026b5456a9be3dd4c8172a45f6f0"
PARENT_AUDITOR_SHA="8023dbf7c64a85a1e60b68da0806cbbe1c4002773212d4380f3d3cee0ecfefd8"
ARTIFACTS=("run.log","parameters.txt","summary.csv","remap_budget.csv","progress.json","peak_fields_0001.bin","peak_channel_0001.csv","fields_0001.bin","channel_0001.csv","checkpoint.bin","status.txt")
def require(ok,message):
    if not ok:raise ValueError(message)
def sha(blob):return hashlib.sha256(blob).hexdigest()
def meta(p):
    s=p.stat();return dict(device=s.st_dev,inode=s.st_ino,bytes=s.st_size,mtime_ns=s.st_mtime_ns)
def read(p):
    a=meta(p);blob=p.read_bytes();b=meta(p)
    require(a==b,"file changed during read: "+str(p))
    return dict(metadata=a,blob=blob)
def capture():
    d={n:read(D/n) for n in ARTIFACTS+("process_status.json",)}
    for n in ("time-step.py","time-step-capture.json","time-step-inputs.tar.xz"):d[n]=read(F/n)
    d["readiness"]=read(B/"tmp/fine125-terminal-002/readiness.json")
    d["manifest"]=read(W/"validation/runs/validation_manifest.json")
    d["provenance"]=read(W/"validation/runs/_inputs/provenance.json")
    return d
require(len(sys.argv)==1,"this terminal-only auditor takes no arguments")
started=datetime.now(timezone.utc).isoformat()
require(not Path("/proc/3831031").exists(),"original PID is not absent")
first=capture();time.sleep(2);second=capture()
require(first==second,"source bytes or metadata changed across observations")
data={n:second[n]["blob"] for n in ARTIFACTS+("process_status.json",)}
process=json.loads(data["process_status.json"])
manifest=json.loads(second["manifest"]["blob"])
require(process["name"]=="fine125" and process["pid"]==3831031 and process["state"]=="complete" and process["exit_code"]==0,"candidate lacks complete exit0 identity")
require([c for c in manifest["cases"] if c["name"]=="fine125"]==[process],"terminal driver record differs")
require(data["status.txt"]==b"complete 1 floods\n","terminal status differs")
require(set(process["artifact_sha256"])==set(ARTIFACTS) and all(sha(data[n])==process["artifact_sha256"][n] for n in ARTIFACTS),"candidate artifact hashes differ")
provenance=json.loads(second["provenance"]["blob"])
require(provenance==manifest["provenance"] and provenance["binary_sha256"]==process["binary_sha256"]==BINARY,"executable provenance differs")
require(provenance["source_sha256"]==SOURCES,"recorded source hashes differ")
require(sha((W/provenance["executable"]).read_bytes())==BINARY,"frozen executable bytes differ")
for name,digest in SOURCES.items():require(sha((W/name).read_bytes())==digest,"frozen numerical source differs: "+name)
for name in ("physics.txt","runs.csv"):require(sha((W/"validation/runs/_inputs"/name).read_bytes())==provenance[name+"_sha256"],"validation input differs: "+name)
require(sha(second["time-step.py"]["blob"])==HELPER and sha(second["time-step-capture.json"]["blob"])==CAPTURE,"retained helper/capture differs")
archive_blob=second["time-step-inputs.tar.xz"]["blob"]
require(sha(archive_blob)==ARCHIVE,"retained archive differs")
archive_capture=json.loads(second["time-step-capture.json"]["blob"])
require(archive_capture["source_identity"]["corrected_binary_sha256"]==BINARY and archive_capture["source_identity"]["frozen_source_sha256"]==SOURCES,"baseline numerical provenance differs")
expected=archive_capture["archive"]["member_sha256"]
require(len(archive_blob)==archive_capture["archive"]["bytes"] and len(expected)==24,"archive size/member count differs")
members={}
with tarfile.open(fileobj=io.BytesIO(archive_blob),mode="r:xz") as archive:
    for item in archive:
        require(item.isfile() and item.name in expected and item.name not in members,"unexpected archive member")
        b=archive.extractfile(item).read()
        require(sha(b)==expected[item.name],"archive member hash differs")
        members[item.name]=b
require(set(members)==set(expected),"archive member set differs")
base={name:members["validation/runs/baseline250/"+name] for name in ARTIFACTS+("process_status.json",)}
base_process=json.loads(base["process_status.json"])
require(base_process["state"]=="complete" and base_process["exit_code"]==0 and base_process["binary_sha256"]==BINARY,"invalid baseline terminal record")
require(set(base_process["artifact_sha256"])==set(ARTIFACTS) and all(sha(base[n])==base_process["artifact_sha256"][n] for n in ARTIFACTS),"baseline artifact hashes differ")
require(sha(second["readiness"]["blob"])==READINESS,"preparation identity evidence differs")
readiness=json.loads(second["readiness"]["blob"])
observed=readiness["second"]
require(observed["pid"]==3831031 and observed["start_ticks"]==51654556 and
        observed["parent"]==3805339 and readiness["cpu_ticks_delta"]>0,"invalid observed original process identity")
require(process["command"]==observed["argv"] and
        process["utc_started"]==observed["record"]["utc_started"],"terminal identity differs from observed original run")
for n,digest in observed["source_sha256"].items():
    require(sha(data[n])==digest,"prepared parameter/peak bytes differ: "+n)
require(datetime.strptime(process["utc_finished"],"%Y-%m-%dT%H:%M:%S.%fZ")>
        datetime.strptime(process["utc_started"],"%Y-%m-%dT%H:%M:%S.%fZ"),"invalid terminal time order")
spec=importlib.util.spec_from_file_location("retained_timestep_helper",str(F/"time-step.py"))
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
def parameters(blob):
    p={}
    for line in blob.decode().splitlines():
        k,v=line.split(" ",1)
        if k=="command":continue
        require(k not in p,"duplicate numerical parameter: "+k)
        p[k]=float(v)
    require(set(p)==set(helper.SIGNATURE_KEYS+["floods"]) and
            all(math.isfinite(v) for v in p.values()),"invalid numerical parameters")
    return p
bp,cp=parameters(base["parameters.txt"]),parameters(data["parameters.txt"])
differences={k:[bp[k],cp[k]] for k in bp if bp[k]!=cp[k]}
require(differences=={"dx":[250.0,125.0]},"sole numerical change is not dx250 to dx125")
require(cp["run"]==11 and cp["floods"]==1 and cp["duration"]==1728000 and cp["dx"]==125 and cp["cfl"]==.4,"wrong candidate scope")

def field(blob,p,phase):
    """Native-grid adapter; retained field() is deliberately left unchanged."""
    require(len(blob)>=40,"truncated raster header")
    nx,ny,nodes,flood,dx,clock,slope=struct.unpack("<4i3d",blob[:40])
    ex,ey=int(p["length"]/p["dx"]),int(p["width"]/p["dx"])
    require(ex*p["dx"]==p["length"] and ey*p["dx"]==p["width"],"grid does not tile domain")
    require((nx,ny,nodes,flood,dx,clock,slope)==
            (ex,ey,289,1,p["dx"],phase*p["duration"],p["slope"]),"unexpected native raster metadata")
    require(len(blob)==40+16*nx*ny,"incorrect native raster payload length")
    cells=list(struct.iter_unpack("<4f",blob[40:]))
    require(all(all(math.isfinite(v) for v in c) and c[1]>=0 and c[2]>=0 and
                c[3] in (0,1) for c in cells),"invalid native raster state")
    return dict(nx=nx,ny=ny,channel_nodes=nodes,flood=flood,dx_m=dx,
                elapsed_seconds=clock,slope=slope),cells

def decimal12_bound(value):
    return 0. if value==0 else .5*10.**(math.floor(math.log10(abs(value)))-11)

def phase_metrics(metadata,cells,rows,p):
    result=helper.snapshot(metadata,cells)
    result["field_minima"]={name:min(c[k] for c in cells) for k,name in
                            enumerate(("bed_m","water_depth_m","event_deposit_m","mask"))}
    result["field_maxima"]={name:max(c[k] for c in cells) for k,name in
                            enumerate(("bed_m","water_depth_m","event_deposit_m","mask"))}
    result["channel_depth_range_m"]=[min(r["water_depth"] for r in rows),max(r["water_depth"] for r in rows)]
    result["channel_control_area_range_m2"]=[min(r["control_area"] for r in rows),max(r["control_area"] for r in rows)]
    result["channel_water_volume_from_csv_m3"]=math.fsum(r["water_depth"]*r["control_area"] for r in rows)
    result["channel_water_csv_rounding_bound_m3"]=math.fsum(
        abs(r["control_area"])*decimal12_bound(r["water_depth"])+
        abs(r["water_depth"])*decimal12_bound(r["control_area"])+
        decimal12_bound(r["water_depth"])*decimal12_bound(r["control_area"]) for r in rows)
    result["floodplain_water_float32_storage_bound_m3"]=math.fsum(helper.half_ulp(c[1]) for c in cells if c[3]==0)*p["dx"]**2
    result["total_water_volume_from_raster_and_csv_m3"]=result["floodplain_water_volume_m3"]+result["channel_water_volume_from_csv_m3"]
    result["total_water_storage_and_csv_bound_m3"]=result["floodplain_water_float32_storage_bound_m3"]+result["channel_water_csv_rounding_bound_m3"]
    density=p["rho_s"]*(1-p["porosity"])
    result["dry_bulk_density_kg_per_m3"]=density
    result["event_deposit_mineral_mass_from_raster_kg"]=result["event_deposit_bulk_volume_m3"]*density
    result["event_deposit_mineral_mass_storage_bound_kg"]=result["event_deposit_bulk_volume_storage_bound_m3"]*density
    result["native_channel_mask_cells"]=sum(c[3]==1 for c in cells)
    return result

def compatible_fields(coarse,fine,coarse_metadata,fine_metadata):
    """Area averages on common, wholly floodplain 250 m squares; no interpolation."""
    nx,ny=coarse_metadata["nx"],coarse_metadata["ny"]
    require(coarse_metadata["dx_m"]==250 and fine_metadata["dx_m"]==125 and
            fine_metadata["nx"]==2*nx and fine_metadata["ny"]==2*ny,
            "comparison grids are not aligned 2:1 refinements")
    pairs=[];counts={};mask_disagreement=0
    for j in range(ny):
        for i in range(nx):
            a=coarse[j*nx+i]
            children=[fine[(2*j+dj)*(2*nx)+2*i+di] for dj in (0,1) for di in (0,1)]
            fine_fp=sum(c[3]==0 for c in children)
            key=("coarse_channel" if a[3] else "coarse_floodplain")+"_fine_floodplain_children_"+str(fine_fp)
            counts[key]=counts.get(key,0)+1
            mask_disagreement+=sum(c[3]!=a[3] for c in children)
            if a[3]==0 and fine_fp==4:pairs.append((a,children))
    require(pairs,"no compatible full floodplain squares")
    out=dict(method="Fine minus baseline after averaging each aligned 2x2 fine block onto its 250 m footprint; only baseline floodplain cells whose four fine children are all floodplain. Dry cells included; mixed or differing masks excluded.",
             coarse_cells=len(pairs),common_area_m2=len(pairs)*250**2,
             excluded_coarse_cells=nx*ny-len(pairs),excluded_total_area_m2=(nx*ny-len(pairs))*250**2,
             excluded_baseline_floodplain_area_m2=(sum(c[3]==0 for c in coarse)-len(pairs))*250**2,
             mask_overlap_coarse_cell_counts=counts,
             raster_mask_disagreement_area_m2=mask_disagreement*125**2,fields={})
    for k,name in enumerate(("bed","water_depth","event_deposit")):
        delta=[math.fsum(c[k] for c in children)/4-a[k] for a,children in pairs]
        bounds=[helper.half_ulp(a[k])+math.fsum(helper.half_ulp(c[k]) for c in children)/4 for a,children in pairs]
        out["fields"][name]=dict(mean_signed_difference_m=math.fsum(delta)/len(delta),
            mean_absolute_difference_m=math.fsum(abs(v) for v in delta)/len(delta),
            maximum_absolute_difference_m=max(abs(v) for v in delta),
            mean_difference_float32_storage_bound_m=math.fsum(bounds)/len(bounds),
            maximum_difference_float32_storage_bound_m=max(bounds),
            integrated_difference_over_common_area_m3=math.fsum(delta)*250**2,
            integrated_difference_float32_storage_bound_m3=math.fsum(bounds)*250**2)
    return out
def channel(blob):
    rows=helper.csv_rows(blob)
    require(len(rows)==289 and all(set(r)=={"x","y","bed","water_depth","velocity","control_area"} for r in rows),"invalid channel schema/count")
    require(all(all(math.isfinite(v) for v in r.values()) and r["water_depth"]>0 and r["control_area"]>0 for r in rows),"invalid channel physical values")
    require(rows[0]["x"]==0 and rows[-1]["x"]==72000 and all(rows[i+1]["x"]-rows[i]["x"]==250 for i in range(288)),"unexpected channel spacing")
    return rows
def decode_arrays(blob,p):
    slen=struct.unpack_from("<Q",blob)[0];at=8+slen
    h=struct.unpack_from("<idqqi4d3d5dQ",blob,at);at+=struct.calcsize("<idqqi4d3d5dQ");n=h[-1]
    def block(fmt,count):
        nonlocal at
        size=struct.calcsize("<"+fmt)*count
        result=list(struct.iter_unpack("<"+fmt,blob[at:at+size]));at+=size
        return result
    line=block("2d",n);ch=block("6d",n)
    size=int(p["length"]/p["dx"])*int(p["width"]/p["dx"])
    bed=[r[0] for r in block("d",size)];q=block("6d",size)
    require(at==len(blob),"independent payload decode length differs")
    require(all(all(math.isfinite(v) for v in r) for r in line+ch+q) and all(math.isfinite(z) for z in bed),"nonfinite array")
    require(all(r[k]>=0 for r in ch+q for k in (0,3,4,5)),"negative physical array")
    dx=p["dx"];nx=int(p["length"]/dx);ny=int(p["width"]/dx);radius=p["channel_width"]/2
    mask=[False]*size
    for a,b in zip(line,line[1:]):
        vx,vy=b[0]-a[0],b[1]-a[1];ll=vx*vx+vy*vy
        require(ll>0,"duplicate checkpoint channel nodes")
        for j in range(max(0,int(math.floor((min(a[1],b[1])-radius)/dx))),min(ny-1,int(math.floor((max(a[1],b[1])+radius)/dx)))+1):
            for i in range(max(0,int(math.floor((min(a[0],b[0])-radius)/dx))),min(nx-1,int(math.floor((max(a[0],b[0])+radius)/dx)))+1):
                px,py=(i+.5)*dx-a[0],(j+.5)*dx-a[1];w=max(0.,min(1.,(px*vx+py*vy)/ll))
                if math.hypot(px-w*vx,py-w*vy)<=radius:mask[j*nx+i]=True
    s=[0.]
    for a,b in zip(line,line[1:]):s.append(s[-1]+math.hypot(b[0]-a[0],b[1]-a[1]))
    area=[.5*(s[min(i+1,n-1)]-s[max(i-1,0)])*p["channel_width"] for i in range(n)]
    require(all(math.isfinite(a) and a>0 for a in area),"invalid reconstructed channel area")
    inventory=[math.fsum([q[i][k]*dx*dx for i in range(size) if not mask[i]]+[row[k]*a for row,a in zip(ch,area)]) for k in (0,3,4,5)]
    bed_mass=math.fsum((z-p["slope"]*(p["length"]-(i%nx+.5)*dx))*p["rho_s"]*(1-p["porosity"])*dx*dx for i,z in enumerate(bed))
    physical_minima={"channel_"+label:min(r[k] for r in ch) for k,label in ((0,"water_depth"),(3,"sand"),(4,"silt"),(5,"clay"))}
    physical_minima.update({"raster_"+label:min(r[k] for r in q) for k,label in ((0,"water_depth"),(3,"sand"),(4,"silt"),(5,"clay"))})
    return dict(inventory=inventory,bed_mass=bed_mass,mask=mask,channel_area_total=math.fsum(area),channel_area_min=min(area),channel_area_max=max(area),channel_area_identity_error=math.fsum(area)-p["channel_width"]*s[-1],physical_minima=physical_minima)

cases={};phase_arrays={};phase_metadata={};geometry={}
for name,p,blobs,rec in (("baseline250",bp,base,base_process),("fine125",cp,data,process)):
    summary=helper.one_row(blobs["summary.csv"]);remap=helper.one_row(blobs["remap_budget.csv"])
    require(all(summary[k]>=0 for k in ("water_storage","bank_mass","recycled_mass","cutoffs","steps","channel_steps")) and
            summary["channel_depth"]>0 and remap["post_water_storage"]>=0,"invalid required scalar inventory")
    phase_arrays[name]={};phase_metadata[name]={};geometry[name]={};phases={}
    for phase,fraction,prefix_file in (("peak",.6,"peak_"),("end",1.,"")):
        md,cells=field(blobs[prefix_file+"fields_0001.bin"],p,fraction)
        rows=channel(blobs[prefix_file+"channel_0001.csv"])
        phases[phase]=phase_metrics(md,cells,rows,p)
        phase_arrays[name][phase]=cells;phase_metadata[name][phase]=md
        geometry[name][phase]=[(r["x"],r["y"],r["control_area"]) for r in rows]
    require(geometry[name]["peak"]==geometry[name]["end"] and
            [c[3] for c in phase_arrays[name]["peak"]]==[c[3] for c in phase_arrays[name]["end"]],
            "first-flood channel geometry or native mask changed before remap")
    peak,end=phases["peak"],phases["end"]
    require(peak["alpha_storage_interval_m"][0] is not None and
            peak["alpha_storage_interval_m"][0]-decimal12_bound(summary["alpha"])<=summary["alpha"]<=
            peak["alpha_storage_interval_m"][1]+decimal12_bound(summary["alpha"]),"peak alpha differs from completed summary")
    require(abs(peak["mean_floodplain_depth_m"]-summary["mean_water"])<=
            peak["mean_depth_storage_bound_m"]+decimal12_bound(summary["mean_water"]),"peak mean depth differs from summary")
    require(peak["definitely_wet_faces"]/peak["interface_faces"]-decimal12_bound(summary["interface_fraction"])<=
            summary["interface_fraction"]<=
            peak["possibly_wet_faces"]/peak["interface_faces"]+decimal12_bound(summary["interface_fraction"]),
            "peak interface fraction differs from summary")
    end["pre_remap_water_minus_summary_m3"]=end["total_water_volume_from_raster_and_csv_m3"]-summary["water_storage"]
    require(abs(end["pre_remap_water_minus_summary_m3"])<=
            end["total_water_storage_and_csv_bound_m3"]+decimal12_bound(summary["water_storage"]),
            "end raster/channel water differs from pre-remap summary")
    cells=phase_arrays[name]["end"]
    stored=helper.checkpoint(blobs["checkpoint.bin"],p,cells)
    require(stored["steps"]==summary["steps"] and stored["channel_steps"]==summary["channel_steps"] and
            stored["steps"]>0 and stored["channel_steps"]>=stored["steps"],"checkpoint/summary counters differ")
    require(stored["recycled_mass_kg"]>=0 and stored["cutoffs"]>=0 and
            stored["water_correction_m3"]>=0 and stored["mass_correction_kg"]>=0,
            "negative required checkpoint inventory")
    require(stored["cutoffs"]>=summary["cutoffs"] and summary["cutoffs"]==int(summary["cutoffs"]),
            "cutoff counter decreased or is nonintegral")
    stored["cutoffs_added_at_first_remap"]=stored["cutoffs"]-int(summary["cutoffs"])
    arrays=decode_arrays(blobs["checkpoint.bin"],p)
    inventory=arrays.pop("inventory");mask=arrays.pop("mask");bed=arrays.pop("bed_mass")
    captured=sum(c[3]==0 and m for c,m in zip(cells,mask))
    abandoned=sum(c[3]==1 and not m for c,m in zip(cells,mask))
    require(captured==stored["captured_floodplain_cells"] and abandoned==stored["abandoned_channel_cells"],
            "independent native-grid remap event counts differ")
    stored["captured_floodplain_area_m2"]=captured*p["dx"]**2
    stored["abandoned_channel_area_m2"]=abandoned*p["dx"]**2
    external=math.fsum(stored["net_external_sediment_by_class_kg"])
    suspension_residual=math.fsum(inventory[1:])+stored["deposited_mass_kg"]-external-stored["mass_correction_kg"]
    fullsolid=bed+math.fsum(inventory[1:])+stored["bank_mass_kg"]
    reaggregation=dict(post_water_and_suspended_class_storage=inventory,
      post_water_storage_minus_ledger_m3=inventory[0]-remap["post_water_storage"],
      independently_reaggregated_suspension_plus_deposition_residual_kg=suspension_residual,
      post_suspension_plus_deposition_residual_minus_ledger_kg=suspension_residual-remap["post_sediment_residual"],
      signed_bed_inventory_relative_to_initial_plane_kg=bed,signed_post_full_solid_inventory_kg=fullsolid,
      implied_initial_water_storage_m3=inventory[0]-stored["net_external_water_m3"]-stored["water_correction_m3"]-remap["post_water_residual"],
      implied_initial_full_solid_inventory_kg=fullsolid+stored["recycled_mass_kg"]-stored["bed_forcing_mass_kg"]-external-stored["mass_correction_kg"]-remap["post_solid_sediment_residual"],
      **arrays)
    require(abs(reaggregation["post_water_storage_minus_ledger_m3"])<.001 and
            abs(reaggregation["post_suspension_plus_deposition_residual_minus_ledger_kg"])<.001,
            "independent inventory reaggregation discrepancy")
    identities=dict(water=remap["post_water_residual"]-summary["water_residual"]-remap["water_transfer_residual"],
      sediment=remap["post_sediment_residual"]-summary["sediment_residual"]-
        math.fsum(remap[k] for k in ("sand_transfer_residual","silt_transfer_residual","clay_transfer_residual")),
      solid=remap["post_solid_sediment_residual"]-summary["solid_sediment_residual"]-remap["solid_transfer_residual"])
    # An unexpected remap correction must be investigated, not silently absorbed into this audit.
    require(abs(identities["water"])<1e-12 and abs(identities["sediment"])<1e-7 and abs(identities["solid"])<1e-7,
            "scalar remap identity differs; inspect possible new correction before broadening")
    storage_identity=remap["post_water_storage"]-summary["water_storage"]-remap["water_transfer_residual"]
    require(abs(storage_identity)<=decimal12_bound(summary["water_storage"])+.00001,"remap storage identity differs")
    inputs=helper.normalization(p);water,sediment=inputs["prescribed_water_input_m3"],inputs["prescribed_sediment_input_kg"]
    normalized=dict(pre_water=summary["water_residual"]/water,pre_suspension_plus_deposition=summary["sediment_residual"]/sediment,
      pre_full_solid=summary["solid_sediment_residual"]/sediment,post_water=remap["post_water_residual"]/water,
      post_suspension_plus_deposition=remap["post_sediment_residual"]/sediment,post_full_solid=remap["post_solid_sediment_residual"]/sediment)
    end["raster_mineral_mass_minus_deposition_source_kg"]=end["event_deposit_mineral_mass_from_raster_kg"]-stored["deposited_mass_kg"]
    require(abs(end["raster_mineral_mass_minus_deposition_source_kg"])<=
            end["event_deposit_mineral_mass_storage_bound_kg"],"pre-remap mineral deposit/source mismatch exceeds float32 storage bound")
    cases[name]=dict(parameters=p,finished_utc=rec["utc_finished"],exit_code=rec["exit_code"],summary=summary,
      remap=remap,checkpoint=stored,checkpoint_bytes=len(blobs["checkpoint.bin"]),inventory_reaggregation=reaggregation,
      scalar_ledger_identity_errors=identities,water_storage_identity_error_m3=storage_identity,
      prescribed_inputs=inputs,signed_normalized_residuals=normalized,peak=peak,end=end,
      hashes={n:sha(blobs[n]) for n in ARTIFACTS})
require(geometry["baseline250"]==geometry["fine125"],"common initial 250 m channel geometry differs")
comparison={}
for metric in ("alpha","interface_fraction","mean_water","beta","ridge_height","channel_depth","water_storage"):
    a,b=cases["baseline250"]["summary"][metric],cases["fine125"]["summary"][metric]
    comparison[metric]=dict(baseline250=a,fine125=b,difference=b-a,percent=100*(b/a-1) if a else None)
a,b=cases["baseline250"]["checkpoint"]["deposited_mass_kg"],cases["fine125"]["checkpoint"]["deposited_mass_kg"]
comparison["deposition_source_mineral_mass_kg"]=dict(baseline250=a,fine125=b,difference=b-a,percent=100*(b/a-1) if a else None)
native={}
for phase in ("peak","end"):
    native[phase]={}
    for metric in ("floodplain_area_m2","floodplain_water_volume_m3","inundated_area_m2",
                   "total_water_volume_from_raster_and_csv_m3","event_deposit_bulk_volume_m3",
                   "event_deposit_mineral_mass_from_raster_kg"):
        a,b=cases["baseline250"][phase][metric],cases["fine125"][phase][metric]
        native[phase][metric]=dict(baseline250=a,fine125=b,difference=b-a,percent=100*(b/a-1) if a else None)
initial_difference={k:cases["fine125"]["inventory_reaggregation"][k]-cases["baseline250"]["inventory_reaggregation"][k]
                   for k in ("implied_initial_water_storage_m3","implied_initial_full_solid_inventory_kg")}
require(not Path("/proc/3831031").exists(),"original PID appeared during terminal audit")
result=dict(started_utc=started,completed_utc=datetime.now(timezone.utc).isoformat(),
    scope="Completed first-flood floodplain-grid sensitivity, dx250 versus dx125 with common 250 m channel nodes. No spatial-convergence order, later-flood or manuscript claim.",
    stable_seconds=2,terminal_manifest_agrees=True,original_pid_absent=True,terminal_process=process,
    observed_original_process=observed,readiness_sha256=READINESS,parent_auditor_sha256=PARENT_AUDITOR_SHA,
    source_provenance_matches=True,binary_sha256=BINARY,frozen_source_sha256=SOURCES,helper_sha256=HELPER,
    baseline_archive_sha256=ARCHIVE,baseline_capture_sha256=CAPTURE,
    prepared_parameter_and_peak_bytes_unchanged=True,parameter_differences=differences,
    candidate_source_files={n:dict(sha256=sha(second[n]["blob"]),**second[n]["metadata"])
                            for n in ARTIFACTS+("process_status.json",)},
    cases=cases,metric_comparison=comparison,native_grid_integral_comparison=native,
    common_250m_footprint_fields={phase:compatible_fields(phase_arrays["baseline250"][phase],phase_arrays["fine125"][phase],
       phase_metadata["baseline250"][phase],phase_metadata["fine125"][phase]) for phase in ("peak","end")},
    implied_initial_inventory_difference_between_grids=initial_difference,
    method=dict(deposition="Checkpoint deposited_mass is cumulative source-integrated mineral mass. The pre-remap raster event_deposit is porous thickness; its native-cell-area integral times rho_s*(1-porosity)=1590 kg/m3 is remaining mineral mass.",
      day12="No prior fine125 report was available. Both day12 and day20 fields are decoded afresh, with preparation-time parameter/peak hashes bound to the observed original live process.",
      fullsolid="Current bed+bank+suspension inventory is independently reaggregated. Initial full-solid reference is inferred independently for each grid from its recorded residual, not regenerated; equality across grids is not required.",
      water="Post-remap water is independently reaggregated from native unmapped raster cells and actual post-remap 1-D control areas. Initial water is inferred independently from each ledger, not regenerated.",
      suspension="Initial suspended inventory is zero in the frozen initializer; the suspension-plus-deposition residual is independently recomputed from arrays and checkpoint source/external/correction ledgers.",
      grid_comparison="Native-grid integrals use each case's own sampled floodplain mask. Local field differences use equal physical 250 m square footprints only where the baseline cell and all four fine children are floodplain; fine cell averages preserve area integrals. Mask disagreements and excluded squares are reported, not treated as matching cells.",
      events="Capture and abandonment are reconstructed separately on each native grid by comparing its pre-remap snapshot mask with the checkpoint centerline capsule mask. Counts and physical areas are reported; no continuous swept-bank interpretation.",
      normalization="Both cases retain C=.003 and concentration_scale=.001. Prescribed upstream water and sediment inputs use each actual parameter set and 20000-interval Simpson integration of Q^2.5. Gross inputs exclude outflow, recycling and signed bed forcing.",
      bounds="Float32 half-ULP bounds quantify serialized raster storage only; common-footprint bounds propagate all four fine-cell errors through their mean. CSV water uses a separate 12-significant-digit rounding bound. These are not discretization or floating-point arithmetic error bounds.",
      phase="Peak day12 and end day20 rasters precede first remap; checkpoint follows remap. Channel CSV lacks its own clock and is paired by the frozen snapshot writer."))
print(json.dumps(result,sort_keys=True,allow_nan=False))
