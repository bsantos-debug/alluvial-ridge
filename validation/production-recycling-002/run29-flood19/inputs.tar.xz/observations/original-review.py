from pathlib import Path
from datetime import datetime,timezone
import csv,io,json,hashlib,math,struct,os
B=Path.cwd();W=B/"tmp/full-rebuild-002/workspace";D=B/"tmp/continuous-observer-002"
pins={}
def sha(b): return hashlib.sha256(b).hexdigest()
def read(p):
 p=Path(p);b=p.read_bytes();pins[str(p.relative_to(B))]=sha(b);return b
def obj(p):return json.loads(read(p))
def ordered(xs):
 total=0.
 for x in xs:total+=x
 return total
started=datetime.now(timezone.utc).isoformat()
auditpath=D/"run29-flood19.json";audit=obj(auditpath)
assert pins[str(auditpath.relative_to(B))]=="928b7093d1387dd93936288f2c6e8bed6527117e627ef1800416a14dfcc76a9a"
c=audit["cases"]["29"];header=c["checkpoint"]
comp=obj(D/"run29-flood19-comparison.json")
assert pins["tmp/continuous-observer-002/run29-flood19-comparison.json"]=="729a2dbc45cc3ae2c5c412773d41591bb3150425c948e4c1b2d90ea16201f2fe"
seed=obj(D/"seed-20261011T092009Z.json");record=seed["cases"]["29"]
for name,expected in audit["frozen_source_sha256"].items():assert sha(read(W/name))==expected
assert sha(read(W/"data/_inputs/ridge"))==audit["binary_sha256"]==record["identity"]["exe_sha256"]
rawp=read(W/"data/run29/parameters.txt");rawstatus=read(W/"data/run29/process_status.json")
assert sha(rawp)==c["hashes"]["parameters.txt"]==record["parameters_sha256"]
assert sha(rawstatus)==c["hashes"]["process_status.json"]==record["process_status_sha256"]
pt=dict(x.split(" ",1) for x in rawp.decode().splitlines() if x)
p={k:float(v) for k,v in pt.items() if k!="command"}
status=json.loads(rawstatus)
assert p["run"]==29 and p["floods"]==580 and p["fine"]==0 and p["C"]==.0003 and p["concentration_scale"]==.001
assert {k:c["identity"][k] for k in record["identity"]}==record["identity"]
assert status["pid"]==c["identity"]["pid"] and int(status["process_start_ticks"])==c["identity"]["start_ticks"]
assert status["command"]==status["current_attempt"]["command"]==c["identity"]["argv"] and "--resume" not in status["command"]
assert {k:pt[k] for k in record["parameter_tokens"]}==record["parameter_tokens"]==comp["parameter_tokens"]
csvrows={}
for filename,section in (("summary.csv","summary"),("remap_budget.csv","remap")):
 b=read(D/"attempts/run29-flood19"/filename);assert sha(b)==c["hashes"][filename]
 rows=list(csv.DictReader(io.StringIO(b.decode())))
 assert [int(r["flood"]) for r in rows]==list(range(1,20))
 assert rows[-1]==comp["current_csv_last_tokens"][filename]
 assert {k:float(v) for k,v in rows[-1].items()}==c[section]
 csvrows[section]=rows
cp_path=W/"data/run29/checkpoint.bin"
with cp_path.open("rb") as f:
 before=os.fstat(f.fileno());blob=f.read();after=os.fstat(f.fileno())
meta=lambda s:[s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns]
actual=sha(blob);expected=c["hashes"]["checkpoint.bin"]
if actual!=expected:
 print(json.dumps({"status":"unavailable","started_utc":started,"observed_utc":datetime.now(timezone.utc).isoformat(),"expected_checkpoint_sha256":expected,"actual_checkpoint_sha256":actual,"checkpoint_open_count":1,"arrays_decoded":False,"reason":"Live checkpoint no longer matches the retained flood19 bytes; no later checkpoint substituted."},indent=2,sort_keys=True))
 raise SystemExit(0)
assert meta(before)==meta(after) and len(blob)==before.st_size
pins[str(cp_path.relative_to(B))]=actual
slen=struct.unpack_from("<Q",blob,0)[0];assert 0<slen<=4096
sig=blob[8:8+slen].decode().split()
keys="length width dx channel_width slope initial_depth duration qmin qmax channel_chezy floodplain_chezy A C E migration_scale perturbation cfl max_dt porosity rho_s tau_critical sand_d silt_ws clay_d diffusion_scale concentration_scale seed run fine migration viscosity".split()
assert len(sig)==32 and sig[0]=="ridge-checkpoint-v2" and all(float(v)==p[k] for k,v in zip(keys,sig[1:]))
fmt="<idqqi4d3d5dQ";h=struct.unpack_from(fmt,blob,8+slen)
flood,clock,steps,chsteps,cutoffs=h[:5];external=list(h[5:9]);bank=list(h[9:12]);deposited,forcing,recycled,wcorr,mcorr=h[12:17];nn=h[17]
assert flood==19 and clock==32832000.==19*p["duration"] and steps==header["steps"] and chsteps==header["channel_steps"]
assert external==[header["net_external_water"]]+header["net_external_sediment"]
assert bank==header["bank"] and [deposited,forcing,recycled,wcorr,mcorr,cutoffs,nn]==[header[k] for k in ("deposited","signed_bed_forcing","recycled","water_correction","mass_correction","cutoffs","nodes")]
assert all(math.isfinite(v) for v in h) and min(bank+[deposited,recycled,cutoffs])>=0
off=8+slen+struct.calcsize(fmt);nx=round(p["length"]/p["dx"]);ny=round(p["width"]/p["dx"]);nc=nx*ny
assert nx*p["dx"]==p["length"] and ny*p["dx"]==p["width"]
assert len(blob)==off+64*nn+56*nc==header["size_bytes"]
def array(fmt,count):
 global off
 size=struct.calcsize(fmt)*count
 a=list(struct.iter_unpack(fmt,memoryview(blob)[off:off+size]));off+=size
 assert len(a)==count and all(math.isfinite(x) for row in a for x in row)
 return a
line=array("<2d",nn);channel=array("<6d",nn);z=[v[0] for v in array("<d",nc)];q=array("<6d",nc);assert off==len(blob)
assert min(v[k] for v in channel for k in (0,3,4,5))>=0 and min(v[k] for v in q for k in (0,3,4,5))>=0
assert all(0<=x<=p["length"] and 0<=y<=p["width"] for x,y in line)
arc=[0.]
for i in range(1,nn):
 seg=math.hypot(line[i][0]-line[i-1][0],line[i][1]-line[i-1][1]);assert seg>0;arc.append(arc[-1]+seg)
areas=[.5*(arc[min(i+1,nn-1)]-arc[i-1 if i else 0])*p["channel_width"] for i in range(nn)]
assert min(areas)>0
radius=.5*p["channel_width"];dx=p["dx"];cellarea=dx*dx
mapping=[None]*nc;best=[float("inf")]*nc;margin=float("inf")
for k in range(nn-1):
 a,b=line[k],line[k+1];vx=b[0]-a[0];vy=b[1]-a[1];ll=vx*vx+vy*vy
 i0=max(0,int(math.floor((min(a[0],b[0])-radius)/dx)));i1=min(nx-1,int(math.floor((max(a[0],b[0])+radius)/dx)))
 j0=max(0,int(math.floor((min(a[1],b[1])-radius)/dx)));j1=min(ny-1,int(math.floor((max(a[1],b[1])+radius)/dx)))
 for j in range(j0,j1+1):
  for i in range(i0,i1+1):
   px=(i+.5)*dx-a[0];py=(j+.5)*dx-a[1];weight=max(0.,min(1.,(px*vx+py*vy)/ll));distance=math.hypot(px-weight*vx,py-weight*vy)
   cell=j*nx+i;margin=min(margin,abs(distance-radius))
   if distance<=radius and distance<best[cell]:best[cell]=distance;mapping[cell]=(k,weight,vx/math.sqrt(ll),vy/math.sqrt(ll))
fp=[i for i,m in enumerate(mapping) if m is None]
mapped=[i for i,m in enumerate(mapping) if m is not None]
def terms(component):
 return [q[i][component]*dx*dx for i in fp]+[channel[i][component]*areas[i] for i in range(nn)]
inventory_comp=[math.fsum(terms(k)) for k in (0,3,4,5)]
inventory_order=[ordered(terms(k)) for k in (0,3,4,5)]
fp_comp=[math.fsum(q[i][k]*dx*dx for i in fp) for k in (0,3,4,5)]
channel_comp=[math.fsum(channel[i][k]*areas[i] for i in range(nn)) for k in (0,3,4,5)]
density=p["rho_s"]*(1-p["porosity"])*dx*dx
bed_terms=[(z[i]-p["slope"]*(p["length"]-(i%nx+.5)*dx))*density for i in range(nc)]
bed_comp=math.fsum(bed_terms);bed_order=ordered(bed_terms)
bank_comp=math.fsum(bank);bank_order=ordered(bank)
full_comp=math.fsum([bed_comp]+inventory_comp[1:]+bank)
full_order=ordered(inventory_order[1:])+bank_order
for term in bed_terms:full_order+=term
zc=[p["slope"]*p["length"]*(1-s/arc[-1])-p["initial_depth"]+(flood-1)*p["A"]+p["A"] for s in arc]
ghost_water_errors=[];ghost_sediment_errors=[];ghost_bed_errors=[]
for i in mapped:
 k,w,tx,ty=mapping[i]
 ghost_water_errors.append(q[i][0]-((1-w)*channel[k][0]+w*channel[k+1][0]))
 ghost_sediment_errors.extend(q[i][j]-((1-w)*channel[k][j]+w*channel[k+1][j]) for j in (3,4,5))
 ghost_bed_errors.append(z[i]-((1-w)*zc[k]+w*zc[k+1]))
r=c["remap"];tot=c["prescribed_hydrographs"]
water_error=inventory_comp[0]-r["post_water_storage"]
sr_comp=math.fsum(inventory_comp[1:])+deposited-math.fsum(external[1:])-mcorr
sr_order=ordered(inventory_order[1:])+deposited
for v in external[1:]:sr_order-=v
sr_order-=mcorr
sed_error=sr_comp-r["post_sediment_residual"]
implied_initial_water=inventory_comp[0]-external[0]-wcorr-r["post_water_residual"]
implied_initial_solid=full_comp+recycled-forcing-math.fsum(external[1:])-mcorr-r["post_solid_sediment_residual"]
assert min(inventory_comp)>=0
for name,val in pins.items():
 if name!=str(cp_path.relative_to(B)):assert sha((B/name).read_bytes())==val,name
out={"status":"verified_bound_current_checkpoint","started_utc":started,"completed_utc":datetime.now(timezone.utc).isoformat(),"checkpoint_open_count":1,"checkpoint_metadata":meta(after),"checkpoint_sha256":actual,"checkpoint_flood":flood,"checkpoint_clock_seconds":clock,"checkpoint_size_bytes":len(blob),"array_layout":{"nodes":nn,"nx":nx,"ny":ny,"full_payload_length_exact":True,"signature_parameters_checked":len(keys),"current_mapped_cells":len(mapped),"current_floodplain_cells":len(fp),"all_array_components_finite":True,"channel_and_raster_water_suspension_nonnegative":True,"min_channel_physical_state":min(v[k] for v in channel for k in (0,3,4,5)),"min_raster_physical_state":min(v[k] for v in q for k in (0,3,4,5))},
"actual_parameter_tokens":{k:pt[k] for k in ("A","C","E","fine","concentration_scale")},"class_fractions":[.05,.75,.20],"channel_geometry":{"length_m":arc[-1],"control_area_sum_m2":math.fsum(areas),"control_area_min_m2":min(areas),"control_area_max_m2":max(areas),"nearest_tested_segment_radius_margin_m":margin,"ghost_water_max_abs_difference_m":max(map(abs,ghost_water_errors)),"ghost_suspension_max_abs_difference_kg_m2":max(map(abs,ghost_sediment_errors)),"ghost_bed_max_abs_difference_m":max(map(abs,ghost_bed_errors))},
"compensated_storage_water_m3_then_suspended_classes_kg":inventory_comp,"source_order_storage_water_m3_then_suspended_classes_kg":inventory_order,"compensated_floodplain_storage":fp_comp,"compensated_channel_storage":channel_comp,
"bank_classes_kg":bank,"bank_compensated_total_kg":bank_comp,"bank_ordinary_total_kg":bank_order,"bank_fraction_differences":[v/bank_comp-f for v,f in zip(bank,[.05,.75,.20])],
"signed_bed_inventory_relative_to_initial_plane_compensated_kg":bed_comp,"signed_bed_inventory_sequential_sum_kg":bed_order,
"signed_total_solid_inventory_compensated_kg":full_comp,"signed_total_solid_inventory_source_order_python_kg":full_order,"compensated_minus_source_order_total_solid_kg":full_comp-full_order,
"water_storage_minus_post_ledger_m3":water_error,"water_reconciliation_normalized":water_error/tot["water"],"source_order_water_minus_post_ledger_m3":inventory_order[0]-r["post_water_storage"],
"suspension_plus_deposition_residual_compensated_kg":sr_comp,"suspension_plus_deposition_residual_source_order_python_kg":sr_order,"recorded_suspension_plus_deposition_residual_kg":r["post_sediment_residual"],"independent_suspension_residual_minus_ledger_kg":sed_error,"suspension_reconciliation_normalized":sed_error/tot["sediment"],"source_order_suspension_residual_minus_ledger_kg":sr_order-r["post_sediment_residual"],
"independent_suspension_plus_deposition_residual_normalized":sr_comp/tot["sediment"],"recorded_post_normalized_residuals":c["post_normalized_residuals"],"prescribed_hydrographs":tot,
"signed_bed_forcing_kg":forcing,"cumulative_recycled_kg":recycled,"corrections":{"water":wcorr,"mass":mcorr},
"implied_initial_water_m3":implied_initial_water,"implied_initial_total_solid_kg":implied_initial_solid,
"existing_reconciliation_guards":{"reference":"tmp/sixth-flood-audit-002/run30-inventory.py:77-80","absolute_water_m3":.001,"absolute_suspension_kg":.001,"water_pass":abs(water_error)<.001,"suspension_pass":abs(sed_error)<.001,"full_solid_guard":None},
"scope":"Single current post-remap checkpoint only. Native double arrays decoded from the one opened hash-matched byte buffer. Water and suspension use physical floodplain cells plus 1D control areas; bed uses all raster cells. Initial water/full-solid references are inferred, not independently regenerated; full-solid closure is not independently established. No prior arrays reconstructed, no capture/abandonment/avulsion counts, no spatial cause attributed. Python ordered sums do not assert compiled C++ bit identity; float32 snapshot bounds do not apply.","auditor_or_model_invocations":0,"files_written":0,"pins":pins}
print(json.dumps(out,indent=2,sort_keys=True))
