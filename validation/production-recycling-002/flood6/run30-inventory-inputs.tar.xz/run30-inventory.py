import ast, hashlib, json, math, os, struct, time
from datetime import datetime, timezone
from pathlib import Path

B = Path('/data/data0/brooke/alluvial-ridge')
W = B / 'tmp/full-rebuild-002/workspace'
D = W / 'data/run30'
AUDIT_SHA = '2558a39aa6ec4fc16eb842261a3e565a3b4d8b348fa3e399a0a052c939fe24ed'
DECODER_SHA = 'd6dc1e7833783c09039d7ce41854ac51de3642c6cfd046298dc5c2b35b1f31fd'

def require(ok, message):
    if not ok:
        raise ValueError(message)

def sha(blob):
    return hashlib.sha256(blob).hexdigest()

audit_blob = (B / 'tmp/sixth-flood-audit-002/run30-flood6.json').read_bytes()
require(sha(audit_blob) == AUDIT_SHA, 'scalar audit changed')
audit = json.loads(audit_blob)
row = audit['cases']['30']
identity = row['identity']

def process():
    proc = Path('/proc') / str(identity['pid'])
    stat = (proc / 'stat').read_text().rsplit(') ', 1)[1].split()
    require(int(stat[19]) == identity['start_ticks'] and int(stat[1]) == 3805340,
            'live process identity changed')
    require(stat[0] not in ('Z', 'X', 'x'), 'process is terminal')
    argv = [v.decode() for v in (proc / 'cmdline').read_bytes().split(b'\0') if v]
    require(argv == identity['argv'], 'argv changed')
    require(sha((proc / 'exe').read_bytes()) == audit['binary_sha256'], 'binary changed')
    require(Path(os.readlink(str(proc / 'cwd'))).resolve() == W.resolve(), 'cwd changed')
    return int(stat[11]) + int(stat[12])

def capture():
    result = {}
    for name, expected in row['hashes'].items():
        path = D / name
        first = path.stat()
        blob = path.read_bytes()
        last = path.stat()
        meta = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns)
        require(meta(first) == meta(last) and sha(blob) == expected, 'artifact changed: ' + name)
        result[name] = (meta(last), blob)
    return result

started = datetime.now(timezone.utc).isoformat()
cpu_before = process()
first = capture()
time.sleep(2)
second = capture()
require(first == second, 'artifacts changed across observations')
for name, expected in audit['frozen_source_sha256'].items():
    require(sha((W / name).read_bytes()) == expected, 'frozen source changed: ' + name)
decoder_blob = (B / 'tmp/concentration-half-terminal-002/audit.py').read_bytes()
require(sha(decoder_blob) == DECODER_SHA, 'reviewed array decoder source changed')
tree = ast.parse(decoder_blob)
functions = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'decode_arrays']
require(len(functions) == 1, 'array decoder function missing or duplicated')
namespace = {'require': require, 'math': math, 'struct': struct}
exec(compile(ast.Module(body=functions), '<reviewed-independent-array-decoder>', 'exec'), namespace)
data = {name: value[1] for name, value in second.items()}
parameters = {k: float(v) for line in data['parameters.txt'].decode().splitlines()
              for k, v in [line.split(' ', 1)] if k != 'command'}
require(parameters['run'] == 30 and parameters['floods'] == 580, 'scope changed')
arrays = namespace['decode_arrays'](data['checkpoint.bin'], parameters)
inventory = arrays.pop('inventory')
mask = arrays.pop('mask')
bed = arrays.pop('bed_mass')
checkpoint, remap = row['checkpoint'], row['remap']
bank = math.fsum(checkpoint['bank'])
fractions = [.05, .20, .75] if parameters['fine'] else [.05, .75, .20]
require(bank > 0 and all(abs(value / bank - fraction) < 1e-12
                        for value, fraction in zip(checkpoint['bank'], fractions)), 'bank class mixture differs')
external = math.fsum(checkpoint['net_external_sediment'])
water_error = inventory[0] - remap['post_water_storage']
sediment_residual = math.fsum(inventory[1:]) + checkpoint['deposited'] - external - checkpoint['mass_correction']
sediment_error = sediment_residual - remap['post_sediment_residual']
require(abs(water_error) < .001 and abs(sediment_error) < .001, 'independent inventory/ledger discrepancy')
full_solid = bed + math.fsum(inventory[1:]) + bank
cpu_after = process()
require(cpu_after >= cpu_before, 'CPU counter reversed')
result = dict(started_utc=started, completed_utc=datetime.now(timezone.utc).isoformat(),
              scalar_audit_sha256=AUDIT_SHA, reviewed_decoder_source_sha256=DECODER_SHA,
              script_sha256=sha(Path(__file__).read_bytes()), artifact_sha256=row['hashes'],
              process_identity=identity, cpu_ticks_delta=cpu_after-cpu_before, stable_seconds=2,
              checkpoint_flood=6, checkpoint_time_seconds=10368000,
              bank_by_class_kg=checkpoint['bank'], bank_total_kg=bank, bank_class_fractions=fractions,
              post_water_and_suspended_class_storage=inventory,
              independent_water_storage_minus_ledger_m3=water_error,
              independent_suspension_plus_deposition_residual_kg=sediment_residual,
              independent_suspension_plus_deposition_residual_minus_ledger_kg=sediment_error,
              signed_bed_inventory_relative_to_initial_plane_kg=bed,
              signed_post_full_solid_inventory_including_bank_kg=full_solid,
              implied_initial_full_solid_inventory_kg=full_solid+checkpoint['recycled']-checkpoint['signed_bed_forcing']-external-checkpoint['mass_correction']-remap['post_solid_sediment_residual'],
              reconstructed_channel_raster_cells=sum(mask), array_checks=arrays,
              limits='Initial water and full-solid inventories were not independently regenerated. No flood-six pre-remap raster/geometry is saved, so capture and abandonment counts and erosion-by-cell are not reconstructed. Bank amount alone does not determine event counts. Summary precedes remap; checkpoint follows remap.')
print(json.dumps(result, sort_keys=True))
