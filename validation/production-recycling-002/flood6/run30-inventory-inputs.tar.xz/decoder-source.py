import csv,hashlib,importlib.util,io,json,math,os,struct,sys,tarfile,time
from pathlib import Path
from datetime import datetime,timezone
sys.dont_write_bytecode=True
B=Path("/data/data0/brooke/alluvial-ridge")
W=B/"tmp/full-rebuild-002/workspace"
D=W/"validation/runs/concentration_half"
F=B/"validation/first-flood-audit-002"
BINARY="b3d984881a2f82757ff9bb6ca7c15f9e3c28e3d34106ae477fe7c06af6f8099c"
HELPER="7e304445cbc8fab0c6eb9068328d3707a9f47906ca21371c5f5b258fd0427073"
ARCHIVE="c604bd946596c7e25d0d4558ef955911d486099a605632fde2f7e65e35db30a6"
CAPTURE="b47e8c73d2ec99445678bb0d47614edbb021f73aba61d492581e6094135f6b5f"
SOURCES={"src/finite_volume.hpp":"57ac8606cd856046e13563fc0f07417943990fbc4f43340baf6f44aad427775d","src/main.cpp":"812058d4ff97b618da08830e44a8704e4dc3a1431e0245136a301a0cd4375c90","src/migration.hpp":"047475c7a53b933ccc83273e0576a820f681382fdf22b244a501006c68bf7196","src/model.hpp":"e12bb6c79a9e70ca53d555fc2d5cfcefed9b0cf2f8a3f7567defd650cc039a15","src/sediment.hpp":"3c698eaf05771c09a26a152697fdcdacacf59b08ad18345efcdcaf1e35ccd4d2"}

PEAK_SHA="8214e052848f7a5a8c223ea61ec6f3e095811d3fcee94b7630ed7d57e0fce05e"
ARTIFACTS=("run.log","parameters.txt","summary.csv","remap_budget.csv","progress.json","peak_fields_0001.bin","peak_channel_0001.csv","fields_0001.bin","channel_0001.csv","checkpoint.bin","status.txt")
def require(ok,message):
    if not ok:raise ValueError(message)
def sha(blob):return hashlib.sha256(blob).hexdigest()
def meta(p):
    s=p.stat();return dict(device=s.st_dev,inode=s.st_ino,bytes=s.st_size,mtime_ns=s.st_mtime_ns)
def read(p):
    a=meta(p);blob=p.read_bytes();b=meta(p)
    require(a==b,"file changed during read: "+str(p))
    return dict(metadata=a,blob=blob)
def capture():
    d={n:read(D/n) for n in ARTIFACTS+("process_status.json",)}
    for n in ("time-step.py","time-step-capture.json","time-step-inputs.tar.xz"):d[n]=read(F/n)
    d["prior_day12"]=read(B/"tmp/concentration-half-peak-002/day12.json")
    d["manifest"]=read(W/"validation/runs/validation_manifest.json")
    d["provenance"]=read(W/"validation/runs/_inputs/provenance.json")
    return d
started=datetime.now(timezone.utc).isoformat()
require(not Path("/proc/97109").exists(),"original PID is not absent")
first=capture();time.sleep(2);second=capture()
require(first==second,"source bytes or metadata changed across observations")
data={n:second[n]["blob"] for n in ARTIFACTS+("process_status.json",)}
process=json.loads(data["process_status.json"])
manifest=json.loads(second["manifest"]["blob"])
require(process["name"]=="concentration_half" and process["pid"]==97109 and process["state"]=="complete" and process["exit_code"]==0,"candidate lacks complete exit0 identity")
require([c for c in manifest["cases"] if c["name"]=="concentration_half"]==[process],"terminal driver record differs")
require(data["status.txt"]==b"complete 1 floods\n","terminal status differs")
require(set(process["artifact_sha256"])==set(ARTIFACTS) and all(sha(data[n])==process["artifact_sha256"][n] for n in ARTIFACTS),"candidate artifact hashes differ")
provenance=json.loads(second["provenance"]["blob"])
require(provenance==manifest["provenance"] and provenance["binary_sha256"]==process["binary_sha256"]==BINARY,"executable provenance differs")
require(provenance["source_sha256"]==SOURCES,"recorded source hashes differ")
require(sha((W/provenance["executable"]).read_bytes())==BINARY,"frozen executable bytes differ")
for name,digest in SOURCES.items():require(sha((W/name).read_bytes())==digest,"frozen numerical source differs: "+name)
for name in ("physics.txt","runs.csv"):require(sha((W/"validation/runs/_inputs"/name).read_bytes())==provenance[name+"_sha256"],"validation input differs: "+name)
require(sha(second["time-step.py"]["blob"])==HELPER and sha(second["time-step-capture.json"]["blob"])==CAPTURE,"retained helper/capture differs")
archive_blob=second["time-step-inputs.tar.xz"]["blob"]
require(sha(archive_blob)==ARCHIVE,"retained archive differs")
archive_capture=json.loads(second["time-step-capture.json"]["blob"])
require(archive_capture["source_identity"]["corrected_binary_sha256"]==BINARY and archive_capture["source_identity"]["frozen_source_sha256"]==SOURCES,"baseline numerical provenance differs")
expected=archive_capture["archive"]["member_sha256"]
require(len(archive_blob)==archive_capture["archive"]["bytes"] and len(expected)==24,"archive size/member count differs")
members={}
with tarfile.open(fileobj=io.BytesIO(archive_blob),mode="r:xz") as archive:
    for item in archive:
        require(item.isfile() and item.name in expected and item.name not in members,"unexpected archive member")
        b=archive.extractfile(item).read()
        require(sha(b)==expected[item.name],"archive member hash differs")
        members[item.name]=b
require(set(members)==set(expected),"archive member set differs")
base={name:members["validation/runs/baseline250/"+name] for name in ARTIFACTS+("process_status.json",)}
base_process=json.loads(base["process_status.json"])
require(base_process["state"]=="complete" and base_process["exit_code"]==0 and base_process["binary_sha256"]==BINARY,"invalid baseline terminal record")
require(set(base_process["artifact_sha256"])==set(ARTIFACTS) and all(sha(base[n])==base_process["artifact_sha256"][n] for n in ARTIFACTS),"baseline artifact hashes differ")
require(sha(second["prior_day12"]["blob"])==PEAK_SHA,"prior day12 audit differs")
prior=json.loads(second["prior_day12"]["blob"])
for name,blobs in (("baseline250",base),("concentration_half",data)):
    for n in ("parameters.txt","peak_fields_0001.bin","peak_channel_0001.csv"):
        require(sha(blobs[n])==prior["cases"][name]["hashes"][n],"previously audited day12 bytes differ")
spec=importlib.util.spec_from_file_location("retained_timestep_helper",str(F/"time-step.py"))
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
def parameters(blob):
    p={k:float(v) for line in blob.decode().splitlines() for k,v in [line.split(" ",1)] if k!="command"}
    require(len(p)==32 and all(math.isfinite(v) for v in p.values()),"invalid numerical parameters")
    return p
bp,cp=parameters(base["parameters.txt"]),parameters(data["parameters.txt"])
differences={k:[bp[k],cp[k]] for k in bp if bp[k]!=cp[k]}
require(differences=={"concentration_scale":[0.001,0.0005]},"sole numerical change is not the concentration scale")
require(cp["run"]==11 and cp["floods"]==1 and cp["duration"]==1728000 and cp["dx"]==250 and cp["cfl"]==.4,"wrong candidate scope")
def channel(blob):
    rows=helper.csv_rows(blob)
    require(len(rows)==289 and all(set(r)=={"x","y","bed","water_depth","velocity","control_area"} for r in rows),"invalid channel schema/count")
    require(all(all(math.isfinite(v) for v in r.values()) and r["water_depth"]>0 and r["control_area"]>0 for r in rows),"invalid channel physical values")
    require(rows[0]["x"]==0 and rows[-1]["x"]==72000 and all(rows[i+1]["x"]-rows[i]["x"]==250 for i in range(288)),"unexpected channel spacing")
    return rows
def decode_arrays(blob,p):
    slen=struct.unpack_from("<Q",blob)[0];at=8+slen
    h=struct.unpack_from("<idqqi4d3d5dQ",blob,at);at+=struct.calcsize("<idqqi4d3d5dQ");n=h[-1]
    def block(fmt,count):
        nonlocal at
        size=struct.calcsize("<"+fmt)*count
        result=list(struct.iter_unpack("<"+fmt,blob[at:at+size]));at+=size
        return result
    line=block("2d",n);ch=block("6d",n)
    size=int(p["length"]/p["dx"])*int(p["width"]/p["dx"])
    bed=[r[0] for r in block("d",size)];q=block("6d",size)
    require(at==len(blob),"independent payload decode length differs")
    require(all(all(math.isfinite(v) for v in r) for r in line+ch+q) and all(math.isfinite(z) for z in bed),"nonfinite array")
    require(all(r[k]>=0 for r in ch+q for k in (0,3,4,5)),"negative physical array")
    dx=p["dx"];nx=int(p["length"]/dx);ny=int(p["width"]/dx);radius=p["channel_width"]/2
    mask=[False]*size
    for a,b in zip(line,line[1:]):
        vx,vy=b[0]-a[0],b[1]-a[1];ll=vx*vx+vy*vy
        require(ll>0,"duplicate checkpoint channel nodes")
        for j in range(max(0,int(math.floor((min(a[1],b[1])-radius)/dx))),min(ny-1,int(math.floor((max(a[1],b[1])+radius)/dx)))+1):
            for i in range(max(0,int(math.floor((min(a[0],b[0])-radius)/dx))),min(nx-1,int(math.floor((max(a[0],b[0])+radius)/dx)))+1):
                px,py=(i+.5)*dx-a[0],(j+.5)*dx-a[1];w=max(0.,min(1.,(px*vx+py*vy)/ll))
                if math.hypot(px-w*vx,py-w*vy)<=radius:mask[j*nx+i]=True
    s=[0.]
    for a,b in zip(line,line[1:]):s.append(s[-1]+math.hypot(b[0]-a[0],b[1]-a[1]))
    area=[.5*(s[min(i+1,n-1)]-s[max(i-1,0)])*p["channel_width"] for i in range(n)]
    require(all(math.isfinite(a) and a>0 for a in area),"invalid reconstructed channel area")
    inventory=[math.fsum([q[i][k]*dx*dx for i in range(size) if not mask[i]]+[row[k]*a for row,a in zip(ch,area)]) for k in (0,3,4,5)]
    bed_mass=math.fsum((z-p["slope"]*(p["length"]-(i%nx+.5)*dx))*p["rho_s"]*(1-p["porosity"])*dx*dx for i,z in enumerate(bed))
    physical_minima={"channel_"+label:min(r[k] for r in ch) for k,label in ((0,"water_depth"),(3,"sand"),(4,"silt"),(5,"clay"))}
    physical_minima.update({"raster_"+label:min(r[k] for r in q) for k,label in ((0,"water_depth"),(3,"sand"),(4,"silt"),(5,"clay"))})
    return dict(inventory=inventory,bed_mass=bed_mass,mask=mask,channel_area_total=math.fsum(area),channel_area_min=min(area),channel_area_max=max(area),channel_area_identity_error=math.fsum(area)-p["channel_width"]*s[-1],physical_minima=physical_minima)
cases={};end_arrays={};end_geometry={}
for name,p,blobs,rec in (("baseline250",bp,base,base_process),("concentration_half",cp,data,process)):
    summary=helper.one_row(blobs["summary.csv"]);remap=helper.one_row(blobs["remap_budget.csv"])
    require(all(summary[k]>=0 for k in ("water_storage","bank_mass","recycled_mass","cutoffs","steps","channel_steps")) and remap["post_water_storage"]>=0,"negative required scalar inventory")
    md,cells=helper.field(blobs["fields_0001.bin"],p,1.)
    end=helper.snapshot(md,cells);rows=channel(blobs["channel_0001.csv"]);peak_rows=channel(blobs["peak_channel_0001.csv"])
    geometry=[(r["x"],r["y"],r["control_area"]) for r in rows]
    require(geometry==[(r["x"],r["y"],r["control_area"]) for r in peak_rows],"channel geometry changed before first remap")
    end_geometry[name]=geometry
    require(struct.unpack("<4i3d",blobs["peak_fields_0001.bin"][:40])==(288,192,289,1,250.,1036800.,p["slope"]),"peak metadata changed")
    require(len(blobs["peak_fields_0001.bin"])==884776,"peak payload size changed")
    stored=helper.checkpoint(blobs["checkpoint.bin"],p,cells)
    require(stored["steps"]==summary["steps"] and stored["channel_steps"]==summary["channel_steps"],"checkpoint counters differ from summary")
    require(stored["recycled_mass_kg"]>=0 and stored["cutoffs"]>=0,"negative checkpoint inventory")
    arrays=decode_arrays(blobs["checkpoint.bin"],p)
    inventory=arrays.pop("inventory");mask=arrays.pop("mask");bed=arrays.pop("bed_mass")
    capture_count=sum(c[3]==0 and m for c,m in zip(cells,mask));abandon_count=sum(c[3]==1 and not m for c,m in zip(cells,mask))
    require(capture_count==stored["captured_floodplain_cells"] and abandon_count==stored["abandoned_channel_cells"],"independent mask event counts differ")
    external=math.fsum(stored["net_external_sediment_by_class_kg"])
    susp_residual=math.fsum(inventory[1:])+stored["deposited_mass_kg"]-external-stored["mass_correction_kg"]
    fullsolid=bed+math.fsum(inventory[1:])+stored["bank_mass_kg"]
    reaggregation=dict(post_water_and_suspended_class_storage=inventory,post_water_storage_minus_ledger_m3=inventory[0]-remap["post_water_storage"],
      independently_reaggregated_suspension_plus_deposition_residual_kg=susp_residual,
      post_suspension_plus_deposition_residual_minus_ledger_kg=susp_residual-remap["post_sediment_residual"],
      signed_bed_inventory_relative_to_initial_plane_kg=bed,signed_post_full_solid_inventory_kg=fullsolid,
      implied_initial_water_storage_m3=inventory[0]-stored["net_external_water_m3"]-stored["water_correction_m3"]-remap["post_water_residual"],
      implied_initial_full_solid_inventory_kg=fullsolid+stored["recycled_mass_kg"]-stored["bed_forcing_mass_kg"]-external-stored["mass_correction_kg"]-remap["post_solid_sediment_residual"],
      **arrays)
    require(abs(reaggregation["post_water_storage_minus_ledger_m3"])<.001 and abs(reaggregation["post_suspension_plus_deposition_residual_minus_ledger_kg"])<.001,"independent inventory reaggregation discrepancy")
    identities=dict(water=remap["post_water_residual"]-summary["water_residual"]-remap["water_transfer_residual"],
      sediment=remap["post_sediment_residual"]-summary["sediment_residual"]-math.fsum(remap[k] for k in ("sand_transfer_residual","silt_transfer_residual","clay_transfer_residual")),
      solid=remap["post_solid_sediment_residual"]-summary["solid_sediment_residual"]-remap["solid_transfer_residual"])
    require(abs(identities["water"])<1e-12 and abs(identities["sediment"])<1e-7 and abs(identities["solid"])<1e-7,"scalar remap identity differs")
    inputs=helper.normalization(p);water,sediment=inputs["prescribed_water_input_m3"],inputs["prescribed_sediment_input_kg"]
    normalized=dict(pre_water=summary["water_residual"]/water,pre_suspension_plus_deposition=summary["sediment_residual"]/sediment,pre_full_solid=summary["solid_sediment_residual"]/sediment,
      post_water=remap["post_water_residual"]/water,post_suspension_plus_deposition=remap["post_sediment_residual"]/sediment,post_full_solid=remap["post_solid_sediment_residual"]/sediment)
    density=p["rho_s"]*(1-p["porosity"])
    end["channel_water_volume_from_csv_m3"]=math.fsum(r["water_depth"]*r["control_area"] for r in rows)
    end["total_water_volume_from_raster_and_csv_m3"]=end["floodplain_water_volume_m3"]+end["channel_water_volume_from_csv_m3"]
    end["floodplain_water_float32_storage_bound_m3"]=math.fsum(helper.half_ulp(c[1]) for c in cells if c[3]==0)*p["dx"]**2
    end["event_deposit_mineral_mass_from_raster_kg"]=end["event_deposit_bulk_volume_m3"]*density
    end["event_deposit_mineral_mass_storage_bound_kg"]=end["event_deposit_bulk_volume_storage_bound_m3"]*density
    end["raster_mineral_mass_minus_deposition_source_kg"]=end["event_deposit_mineral_mass_from_raster_kg"]-stored["deposited_mass_kg"]
    cases[name]=dict(parameters=p,finished_utc=rec["utc_finished"],exit_code=rec["exit_code"],summary=summary,remap=remap,checkpoint=stored,
      checkpoint_bytes=len(blobs["checkpoint.bin"]),inventory_reaggregation=reaggregation,scalar_ledger_identity_errors=identities,
      prescribed_inputs=inputs,signed_normalized_residuals=normalized,end=end,peak=prior["cases"][name],
      hashes={n:sha(blobs[n]) for n in ARTIFACTS})
    end_arrays[name]=cells
require(end_geometry["baseline250"]==end_geometry["concentration_half"],"baseline/candidate first-flood geometry differs")
comparison={}
for metric in ("alpha","beta","ridge_height","channel_depth","water_storage"):
    a,b=cases["baseline250"]["summary"][metric],cases["concentration_half"]["summary"][metric]
    comparison[metric]=dict(baseline250=a,concentration_half=b,difference=b-a,percent=100*(b/a-1))
a,b=cases["baseline250"]["checkpoint"]["deposited_mass_kg"],cases["concentration_half"]["checkpoint"]["deposited_mass_kg"]
comparison["deposition_source_mineral_mass_kg"]=dict(baseline250=a,concentration_half=b,difference=b-a,percent=100*(b/a-1))
initial_difference={k:cases["concentration_half"]["inventory_reaggregation"][k]-cases["baseline250"]["inventory_reaggregation"][k] for k in ("implied_initial_water_storage_m3","implied_initial_full_solid_inventory_kg")}
result=dict(started_utc=started,completed_utc=datetime.now(timezone.utc).isoformat(),scope="Completed first-flood concentration-scale sensitivity at dx250/CFL0.4; no convergence order, later behavior or manuscript claim.",
    stable_seconds=2,terminal_manifest_agrees=True,original_pid_absent=True,terminal_process=process,
    source_provenance_matches=True,binary_sha256=BINARY,frozen_source_sha256=SOURCES,helper_sha256=HELPER,baseline_archive_sha256=ARCHIVE,baseline_capture_sha256=CAPTURE,
    reused_day12_report_sha256=PEAK_SHA,day12_bytes_unchanged=True,parameter_differences=differences,
    candidate_source_files={n:dict(sha256=sha(second[n]["blob"]),**second[n]["metadata"]) for n in ARTIFACTS+("process_status.json",)},
    cases=cases,metric_comparison=comparison,same_grid_fields=dict(peak=prior["same_grid_fields"],end=helper.compare_fields(end_arrays["baseline250"],end_arrays["concentration_half"],250)),
    implied_common_initial_inventory_difference=initial_difference,
    method=dict(deposition="Checkpoint deposited_mass is cumulative source-integrated mineral mass. Raster event_deposit is porous thickness; its integral times rho_s*(1-porosity)=1590 kg/m3 is remaining mineral mass.",
      day12="Previously verified day12 metrics are reused only after checking the prior report hash and exact retained/live parameter/raster/channel hashes. End fields and checkpoint are newly decoded.",
      fullsolid="Current bed+bank+suspension inventory is independently reaggregated. Initial full-solid reference is inferred from the recorded residual and compared across common initial geometry; it was not independently regenerated.",
      water="Post-remap water is independently reaggregated from unmapped raster cells and actual post-remap 1-D areas. Initial water is inferred from the ledger; not independently regenerated.",
      suspension="Initial suspended inventory is zero in the frozen initializer; the suspension-plus-deposition residual is independently recomputed from arrays and checkpoint source/external/correction ledgers.",
      normalization="Each case uses its own prescribed upstream concentration scale: 0.001 baseline and 0.0005 candidate, with 20000-interval Simpson integration of Q^2.5. Gross inputs exclude outflow, recycling and signed bed forcing.",
      bounds="Raster comparisons use float32 half-ULP storage bounds only; exclude discretization, separate arithmetic and CSV rounding.",
      phase="Peak day12 and end day20 rasters precede first remap; checkpoint follows remap. Channel CSV lacks its own clock and is paired by the frozen snapshot writer."))
print(json.dumps(result,sort_keys=True,allow_nan=False))
